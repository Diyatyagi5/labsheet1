import csv

name = input("Enter name: ")

with open("student.csv", "r") as f:
    for row in csv.DictReader(f):
        if row["Name"].lower() == name.lower():
            print(row)
            break
    else:
        print("Student not found")
