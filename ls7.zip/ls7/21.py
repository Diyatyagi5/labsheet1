import csv

f = open("student.csv", "w", newline="")
w = csv.writer(f)

w.writerow(["Name", "Marks"])
w.writerow(["Bhavna", 85])
w.writerow(["Priyanshi", 90])

f.close()
print("CSV file created")
