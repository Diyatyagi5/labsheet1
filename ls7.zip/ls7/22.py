import csv

f = open("student.csv", "r")
for row in csv.reader(f):
    print(row)
f.close()
