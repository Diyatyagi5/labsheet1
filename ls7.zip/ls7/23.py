import csv

f = open("student.csv", "r")
rows = list(csv.reader(f))
f.close()

marks = [int(row[1]) for row in rows[1:]]
print("Average:", sum(marks) / len(marks))
