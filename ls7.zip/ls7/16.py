f = open("data.txt", "r")
lines = f.readlines()
f.close()

if lines:
    print("First:", lines[0].strip())
    print("Last:", lines[-1].strip())
