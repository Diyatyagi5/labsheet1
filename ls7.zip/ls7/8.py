f = open("data.txt", "a")
f.write("\nNew content")
f.close()
print("Content appended")
