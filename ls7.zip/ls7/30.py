import csv

with open("student.csv", "r") as f1:
    data1 = list(csv.reader(f1))

with open("copy.csv", "r") as f2:
    data2 = list(csv.reader(f2))

with open("combined.csv", "w", newline="") as f3:
    w = csv.writer(f3)
    w.writerows(data1)
    w.writerows(data2[1:])

print("CSV files combined")
