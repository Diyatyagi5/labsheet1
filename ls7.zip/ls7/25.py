import csv

f = open("student.csv", "a", newline="")
w = csv.writer(f)
w.writerow(["Tarunima", 80])
f.close()

print("Record added")
