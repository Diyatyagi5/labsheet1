f = open("data.txt", "r")
lines = f.readlines()
f.close()

print(max(lines, key=len).strip())
