import csv

with open("student.csv", "r") as f:
    for row in csv.DictReader(f):
        print(row["Name"], row["Marks"])
