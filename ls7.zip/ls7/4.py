f = open("data.txt", "r")
data = f.read()
print("Words:", len(data.split()))
f.close()
