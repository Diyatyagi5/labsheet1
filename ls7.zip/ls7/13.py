# Create a file and write numbers
f = open("num.txt", "w")
f.write("10 20 30 40 50")
f.close()

# Read numbers from the file
f = open("num.txt", "r")
nums = list(map(int, f.read().split()))
f.close()

# Calculate sum and average
print("Numbers:", nums)
print("Sum:", sum(nums))
print("Average:", sum(nums) / len(nums))
