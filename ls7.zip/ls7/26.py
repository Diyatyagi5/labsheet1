import csv

with open("student.csv", "r") as f:
    data = list(csv.reader(f))

with open("copy.csv", "w", newline="") as f:
    csv.writer(f).writerows(data)

print("CSV copied")
