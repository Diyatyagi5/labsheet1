import csv

f = open("student.csv", "r")
rows = list(csv.reader(f))
f.close()

print("Rows:", len(rows))
print("Columns:", len(rows[0]) if rows else 0)
