import csv

with open("student.csv", "r") as f:
    rows = list(csv.DictReader(f))

topper = max(rows, key=lambda x: int(x["Marks"]))
print("Highest marks:", topper["Marks"])
