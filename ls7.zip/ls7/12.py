f = open("data.txt", "r")
data = f.read()
f.close()

word = input("Enter word: ")
print("Occurrences:", data.split().count(word))
