f = open("data.txt", "r")
data = f.read()
f.close()

word = input("Enter word: ")

if word in data.split():
    print("Word found")
else:
    print("Word not found")
