f1 = open("data.txt", "r")
data1 = f1.read()
f1.close()

f2 = open("copy.txt", "r")
data2 = f2.read()
f2.close()

f3 = open("merged.txt", "w")
f3.write(data1 + "\n" + data2)
f3.close()

print("Files merged")
