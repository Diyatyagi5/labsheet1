Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
# Add two integers

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

sum = a + b

print("Sum =", sum)
SyntaxError: multiple statements found while compiling a single statement
[DEBUG ON]
[DEBUG OFF]

======== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num.py ========
14

====== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/addition.py =====
Enter first number: 6SyntaxError: multiple statements found while compiling a single statement
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/addition.py", line 3, in <module>
    a = int(input("Enter first number: "))
ValueError: invalid literal for int() with base 10: '6SyntaxError: multiple statements found while compiling a single statement'

=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/addition.py ===============================================
Enter first number: 2 
Enter second number: 5 
Sum = 7

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/sub.py =================================================
Enter first number: 6 
Enter second number: 3 
Difference = 3

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/product.py ===============================================
Enter first number: 5 
Enter second number: 3 
Product = 15

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/div.py =================================================
Enter dividend: 8
Enter divisor: 2
Quotient = 4
Remainder = 0

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/sq.py ==================================================
Enter a number: 7
Square = 49
Cube = 343

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/ar_rect.py ===============================================
Enter length: 7
Enter breadth: 4
Area of rectangle = 28.0

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/peri.py =================================================
Enter radius: 6
Perimeter of circle = 37.68

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/swap.py =================================================
Enter first number: 6
Enter second number: 9
After swapping:
First number = 9
Second number = 6

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/swap2.py ================================================
Enter first number: 8
Enter second number: 3
After swapping:
First number = 3
Second number = 8

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/degree.py ================================================
Enter temperature in Celsius: 39
Temperature in Fahrenheit = 102.2

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/degree2.py ===============================================
Enter temperature in Fahrenheit: 104
Temperature in Celsius = 40.0

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/si.py ==================================================
Enter principal amount: 800
Enter rate of interest: 4
Enter time in years: 2
Simple Interest = 64.0

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/ci.py ==================================================
Enter principal amount: 5000
Enter rate of interest: 7
Enter time in years: 3
Compound Interest = 1125.2150000000001

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/avg.py =================================================
Enter first number: 183
Enter second number: 176
Enter third number: 388
Average = 249.0

========================================================== RESTART: C:/Users/hp/OneDrive/Documents/km.py ==========================================================
Enter distance in kilometers: 300
Distance in miles = 186.4113

======================================================= RESTART: C:/Users/hp/OneDrive/Documents/reminder.py =======================================================
Enter first number: 78
Enter second number: 3
Remainder = 0

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/power.py ================================================
Enter base: 98
Enter exponent: 3
Result = 941192

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/bmi.py =================================================
Enter weight in kg: 53
Enter height in meters: 153
BMI = 0.0022640864624716987

================================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/emi.py =================================================
Enter loan amount: 67000
Enter annual interest rate (%): 2
Enter loan period in years: 4
Monthly EMI = 1453.5732838357717

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/percent.py ===============================================
Enter marks of subject 1: 30
Enter marks of subject 2: 40
Enter marks of subject 3: 50
Enter marks of subject 4: 80
Enter marks of subject 5: 30
Total Marks = 230.0
Percentage = 46.0 %

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/percent.py ===============================================
maximum marks in every subject = 100
Enter marks of subject 1: 60
Enter marks of subject 2: 80
Enter marks of subject 3: 78
Enter marks of subject 4: 69
Enter marks of subject 5: 89
Total Marks = 376.0
Percentage = 75.2 %

=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/int_check.py ==============================================
Enter a number: .987
Number is positive

=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/int_check.py ==============================================
Enter a number: -59
Number is negative

=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/even_odd.py ===============================================
Enter a number: 57
Number is odd

================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/multi_5.py ===============================================
Enter a number: 
================================================ RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/multi_5.py ===============================================
Enter a number: 3002
Number is not divisible by 5

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/leap.py =================================================
Enter a year: 2004
It is a leap year

============================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/large_in2num.py =============================================
Enter first number: 57
Enter second number: 87
Largest number = 87.0

============================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/large_in3num.py =============================================
Enter first number: 9
Enter second number: 58
Enter third number: 38
Largest number = 58.0

================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/alpha.py ================================================
Enter a character: b
Character is a consonant
>>> 
================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/alpha.py ================================================
Enter a character: O
Character is a vowel
>>> 
============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/alpha_check.py =============================================
Enter a character: 7g
Character is a digit
>>> 
============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/alpha_check.py =============================================
Enter a character: g9
Character is lowercase
>>> 
=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num_range.py ==============================================
Enter a number: 67
Enter lower limit: tg
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num_range.py", line 4, in <module>
    lower = int(input("Enter lower limit: "))
ValueError: invalid literal for int() with base 10: 'tg'
>>> 
=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num_range.py ==============================================
Enter a number: 400
Enter lower limit: t
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num_range.py", line 4, in <module>
    lower = int(input("Enter lower limit: "))
ValueError: invalid literal for int() with base 10: 't'
>>> 
=============================================== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/num_range.py ==============================================
Enter a number: 67
Enter lower limit: 4
Enter upper limit: 9
Number is not in the given range
>>> 
================================================= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/prime.py ================================================
Enter a number: 67
Number is prime
