# Check divisibility by 5

number = int(input("Enter a number: "))

if number % 5 == 0:
    print("Number is divisible by 5")
else:
    print("Number is not divisible by 5")
