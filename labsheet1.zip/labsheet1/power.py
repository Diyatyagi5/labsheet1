# Calculate power without using pow()

base = int(input("Enter base: "))
exponent = int(input("Enter exponent: "))

result = base ** exponent

print("Result =", result)
