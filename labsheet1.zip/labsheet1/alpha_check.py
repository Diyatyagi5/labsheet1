# Check character type

ch = input("Enter a character: ")

if ch >= 'A' and ch <= 'Z':
    print("Character is uppercase")
elif ch >= 'a' and ch <= 'z':
    print("Character is lowercase")
elif ch >= '0' and ch <= '9':
    print("Character is a digit")
else:
    print("Special character")
