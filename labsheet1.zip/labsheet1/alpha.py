# Check vowel or consonant

ch = input("Enter a character: ")

if ch in "aeiouAEIOU":
    print("Character is a vowel")
else:
    print("Character is a consonant")
