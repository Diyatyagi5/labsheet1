# Calculate perimeter of circle

radius = float(input("Enter radius: "))

pi = 3.14
perimeter = 2 * pi * radius

print("Perimeter of circle =", perimeter)
