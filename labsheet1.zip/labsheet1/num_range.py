# Check number in given range

number = int(input("Enter a number: "))
lower = int(input("Enter lower limit: "))
upper = int(input("Enter upper limit: "))

if number >= lower and number <= upper:
    print("Number is in the given range")
else:
    print("Number is not in the given range")
