num=14
print (num)
