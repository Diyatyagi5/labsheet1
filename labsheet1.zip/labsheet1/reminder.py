# Find remainder

number1 = int(input("Enter first number: "))
number2 = int(input("Enter second number: "))

remainder = number1 % number2

print("Remainder =", remainder)
