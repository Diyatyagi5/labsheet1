# Multiply two integers

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

product = a * b

print("Product =", product)
