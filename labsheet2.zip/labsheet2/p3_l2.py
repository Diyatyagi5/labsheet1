# Check Armstrong number

number = int(input("Enter a number: "))

original = number
digits = 0
temp = number

while temp > 0:
    digits = digits + 1
    temp = temp // 10

sum = 0
temp = number

while temp > 0:
    digit = temp % 10
    sum = sum + digit ** digits
    temp = temp // 10

if sum == original:
    print("Number is an Armstrong number")
else:
    print("Number is not an Armstrong number")
