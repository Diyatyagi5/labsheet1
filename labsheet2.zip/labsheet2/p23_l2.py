# Check perfect number

number = int(input("Enter a number: "))

sum = 0

for i in range(1, number):
    if number % i == 0:
        sum = sum + i

if sum == number:
    print("Number is a perfect number")
else:
    print("Number is not a perfect number")
