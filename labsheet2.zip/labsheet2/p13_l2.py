# Find sum of first n natural numbers

n = int(input("Enter value of n: "))

sum = 0

for i in range(1, n + 1):
    sum = sum + i

print("Sum =", sum)
