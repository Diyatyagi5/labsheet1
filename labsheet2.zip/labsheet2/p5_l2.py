# Find absolute value

number = float(input("Enter a number: "))

if number < 0:
    number = -number

print("Absolute value =", number)
