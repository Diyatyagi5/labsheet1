# Count digits of a number

number = int(input("Enter a number: "))

count = 0
temp = number

if temp == 0:
    count = 1
else:
    while temp > 0:
        count = count + 1
        temp = temp // 10

print("Number of digits =", count)
