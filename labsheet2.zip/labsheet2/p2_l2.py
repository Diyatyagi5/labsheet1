# Check palindrome number

number = int(input("Enter a number: "))

original = number
reverse = 0

while number > 0:
    digit = number % 10
    reverse = reverse * 10 + digit
    number = number // 10

if original == reverse:
    print("Number is a palindrome")
else:
    print("Number is not a palindrome")
