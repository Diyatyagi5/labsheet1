# Print prime numbers from 1 to 100

for number in range(2, 101):
    prime = True

    for i in range(2, number):
        if number % i == 0:
            prime = False
            break

    if prime:
        print(number)
