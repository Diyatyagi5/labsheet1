# Display multiplication tables from 1 to 10

for number in range(1, 11):
    print("Table of", number)

    for i in range(1, 11):
        print(number, "x", i, "=", number * i)

    print()
