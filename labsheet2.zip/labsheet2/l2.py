.333333333333333333333333333Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p1_l2.py =======
Enter a number: 79
Number is not a multiple of both 3 and 7

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p1_l2.py =======
Enter a number: 189
Number is a multiple of both 3 and 7

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p2_l2.py =======
Enter a number: 14741
Number is a palindrome

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p2_l2.py =======
Enter a number: 14514
Number is not a palindrome

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p25_l2.py ======
* * * * * 
* * * * 
* * * 
* * 
* 

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p24_l2.py ======
* * * * * 
* * * * 
* * * 
* * 
* 

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p21_l2.py ======
Enter a number: 167895678
Sum of digits = 57

======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p27_l2.py ======
Table of 1
1 x 1 = 1
1 x 2 = 2
1 x 3 = 3
1 x 4 = 4
1 x 5 = 5
1 x 6 = 6
1 x 7 = 7
1 x 8 = 8
1 x 9 = 9
1 x 10 = 10

Table of 2
2 x 1 = 2
2 x 2 = 4
2 x 3 = 6
2 x 4 = 8
2 x 5 = 10
2 x 6 = 12
2 x 7 = 14
2 x 8 = 16
2 x 9 = 18
2 x 10 = 20

Table of 3
3 x 1 = 3
3 x 2 = 6
3 x 3 = 9
3 x 4 = 12
3 x 5 = 15
3 x 6 = 18
3 x 7 = 21
3 x 8 = 24
3 x 9 = 27
3 x 10 = 30

Table of 4
4 x 1 = 4
4 x 2 = 8
4 x 3 = 12
4 x 4 = 16
4 x 5 = 20
4 x 6 = 24
4 x 7 = 28
4 x 8 = 32
4 x 9 = 36
4 x 10 = 40

Table of 5
5 x 1 = 5
5 x 2 = 10
5 x 3 = 15
5 x 4 = 20
5 x 5 = 25
5 x 6 = 30
5 x 7 = 35
5 x 8 = 40
5 x 9 = 45
5 x 10 = 50

Table of 6
6 x 1 = 6
6 x 2 = 12
6 x 3 = 18
6 x 4 = 24
6 x 5 = 30
6 x 6 = 36
6 x 7 = 42
6 x 8 = 48
6 x 9 = 54
6 x 10 = 60

Table of 7
7 x 1 = 7
7 x 2 = 14
7 x 3 = 21
7 x 4 = 28
7 x 5 = 35
7 x 6 = 42
7 x 7 = 49
7 x 8 = 56
7 x 9 = 63
7 x 10 = 70

Table of 8
8 x 1 = 8
8 x 2 = 16
8 x 3 = 24
8 x 4 = 32
8 x 5 = 40
8 x 6 = 48
8 x 7 = 56
8 x 8 = 64
8 x 9 = 72
8 x 10 = 80

Table of 9
9 x 1 = 9
9 x 2 = 18
9 x 3 = 27
9 x 4 = 36
9 x 5 = 45
9 x 6 = 54
9 x 7 = 63
9 x 8 = 72
9 x 9 = 81
9 x 10 = 90

Table of 10
10 x 1 = 10
10 x 2 = 20
10 x 3 = 30
10 x 4 = 40
10 x 5 = 50
10 x 6 = 60
10 x 7 = 70
10 x 8 = 80
10 x 9 = 90
10 x 10 = 100


======= RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p28_l2.py ======
Enter first number: 56
Enter second number: 14
HCF = 14

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p29_l2.py ===
Enter first number: 45
Enter second number: 16
LCM = 720

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p30_l2.py ===
Enter a number: 167
Number is not a strong number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p30_l2.py ===
Enter a number: 120
Number is not a strong number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p16_l2.py ===
1
3
5
7
9
11
13
15
17
19
21
23
25
27
29
31
33
35
37
39
41
43
45
47
49

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p17_l2.py ===
Enter a number: 16
Factorial = 20922789888000

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p18_l2.py ===
Enter number of terms: 10
0 1 1 2 3 5 8 13 21 34 

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p19_l2.py ===
Enter a number: 5678784232
Reverse = 2324878765

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p20_l2.py ===
Enter a number: 24687954354
Number of digits = 11

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p22_l2.py ===
2
3
5
7
11
13
17
19
23
29
31
37
41
43
47
53
59
61
67
71
73
79
83
89
97

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p23_l2.py ===
Enter a number: 488543
Number is not a perfect number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p23_l2.py ===
Enter a number: 8128
Number is a perfect number

==== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p24_l2.py ===
* 
* * 
* * * 
* * * * 
* * * * * 

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p26_l2.py ===
Enter number of rows: 6
1 
1 2 
1 2 3 
1 2 3 4 
1 2 3 4 5 
1 2 3 4 5 6 

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p30_l2.py ===
Enter a number: 
==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p30_l2.py ===
Enter a number: 145
Number is a strong number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p3_l2.py ====
Enter a number: 3657
Number is not an Armstrong number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p3_l2.py ====
Enter a number: 1634
Number is an Armstrong number

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p4_l2.py ====
Enter marks: 56
Grade = C
49
49

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p4_l2.py ====
Enter marks: 76
Grade = B

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p5_l2.py ====
Enter a number: -78
Absolute value = 78.0

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p7_l2.py ====
Enter first side: 15
Enter second side: 13
Enter third side: 4
Scalene triangle

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p7_l2.py ====
Enter first side: 31
Enter second side: 31
Enter third side: 31
Equilateral triangle

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p7_l2.py ====
Enter first side: 12
Enter second side: 12
Enter third side: 17
Isosceles triangle

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p6_l2.py ====
Enter first angle: 45
Enter second angle: 60
Enter third angle: 75
Triangle is valid

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p6_l2.py ====
Enter first angle: 24
Enter second angle: 67
Enter third angle: 59
Triangle is not valid

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p12_l2.py ===
10
9
8
7
6
5
4
3
2
1

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p8_l2.py ====
Enter a string: hiii tarunima
Enter substring: taru
Substring is present

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p9_l2.py ====
Enter your age: 67
Eligible for voting

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p13_l2.py ===
Enter value of n: 16
Sum = 136

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p15_l2.py ===
2
4
6
8
10
12
14
16
18
20
22
24
26
28
30
32
34
36
38
40
42
44
46
48
50

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p14_l2.py ===
Enter a number: 56
56 x 1 = 56
56 x 2 = 112
56 x 3 = 168
56 x 4 = 224
56 x 5 = 280
56 x 6 = 336
56 x 7 = 392
56 x 8 = 448
56 x 9 = 504
56 x 10 = 560

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p10_l2.py ===
Enter first number: 56
Enter second number: 65
Enter third number: 35
Smallest number = 35.0

==== RESTART: C:\Users\hp\OneDrive\Documents\MCA\PYTHON\code\p11_l2.py ===
1
2
3
4
5
6
7
8
9
10
