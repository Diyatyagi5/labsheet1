# Print multiplication table of given number

number = int(input("Enter a number: "))

for i in range(1, 11):
    print(number, "x", i, "=", number * i)
