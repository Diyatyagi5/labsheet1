Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
======= RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p24_l2.py ======
* * * * * 
* * * * 
* * * 
* * 
* 
>>> 
================ RESTART: C:/Users/hp/OneDrive/Documents/fab.py ================
Enter a number: 30
Factorial = 265252859812191058636308480000000
>>> 
================ RESTART: C:/Users/hp/OneDrive/Documents/fib.py ================
Enter number of terms: 30
0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 4181 6765 10946 17711 28657 46368 75025 121393 196418 317811 514229 
>>> 
================ RESTART: C:/Users/hp/OneDrive/Documents/fib.py ================
Enter number of terms: 30
0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 4181 6765 10946 17711 28657 46368 75025 121393 196418 317811 514229 
Mean = 44875.6
Largest term = 514229
Smallest term = 0
