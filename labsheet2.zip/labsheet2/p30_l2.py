# Check strong number

number = int(input("Enter a number: "))

original = number
sum = 0

while number > 0:
    digit = number % 10

    factorial = 1
    for i in range(1, digit + 1):
        factorial = factorial * i

    sum = sum + factorial
    number = number // 10

if sum == original:
    print("Number is a strong number")
else:
    print("Number is not a strong number")
